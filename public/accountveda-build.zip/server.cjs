var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_vite = require("vite");
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  const customAssetsDir = import_path.default.join(process.cwd(), "custom_assets");
  if (!import_fs.default.existsSync(customAssetsDir)) {
    import_fs.default.mkdirSync(customAssetsDir, { recursive: true });
  }
  app.use("/custom_assets", import_express.default.static(customAssetsDir));
  const imagesDir = import_path.default.join(process.cwd(), "src/assets/images");
  if (import_fs.default.existsSync(imagesDir)) {
    const backupFiles = [
      { src: "accountveda_logo.svg", dest: "default_logo.svg" },
      { src: "founder_chaitali_1782221629255.jpg", dest: "default_chaitali.jpg" },
      { src: "founder_dhaval_1782221644891.jpg", dest: "default_dhaval.jpg" }
    ];
    backupFiles.forEach((file) => {
      const srcPath = import_path.default.join(imagesDir, file.src);
      const destPath = import_path.default.join(imagesDir, file.dest);
      if (import_fs.default.existsSync(srcPath) && !import_fs.default.existsSync(destPath)) {
        try {
          import_fs.default.copyFileSync(srcPath, destPath);
          console.log(`Created backup of default asset: ${file.dest}`);
        } catch (err) {
          console.error(`Failed to create backup of ${file.src}:`, err);
        }
      }
    });
  }
  app.use(import_express.default.json({ limit: "15mb" }));
  app.get("/api/custom-assets-status", (req, res) => {
    try {
      const status = {
        logo: import_fs.default.existsSync(import_path.default.join(customAssetsDir, "logo.svg")),
        chaitali: import_fs.default.existsSync(import_path.default.join(customAssetsDir, "chaitali.jpg")),
        dhaval: import_fs.default.existsSync(import_path.default.join(customAssetsDir, "dhaval.jpg"))
      };
      return res.json(status);
    } catch (error) {
      console.error("Error getting asset status:", error);
      return res.status(500).json({ error: error.message || "Internal server error" });
    }
  });
  app.post("/api/save-assets", (req, res) => {
    try {
      const { id, dataUrl } = req.body;
      if (!id || !dataUrl) {
        return res.status(400).json({ error: "Missing id or dataUrl" });
      }
      const matches = dataUrl.match(/^data:(image\/[a-z0-9-+.]+);base64,(.*)$/);
      if (!matches) {
        return res.status(400).json({ error: "Invalid data URL format" });
      }
      const mimeType = matches[1];
      const base64Data = matches[2];
      const buffer = Buffer.from(base64Data, "base64");
      let targetPath = "";
      let customPath = "";
      if (id === "chaitali") {
        targetPath = import_path.default.join(process.cwd(), "src/assets/images/founder_chaitali_1782221629255.jpg");
        customPath = import_path.default.join(customAssetsDir, "chaitali.jpg");
        import_fs.default.writeFileSync(targetPath, buffer);
        import_fs.default.writeFileSync(customPath, buffer);
        console.log(`Successfully updated founder Chaitali's photo at ${targetPath} and ${customPath}`);
      } else if (id === "dhaval") {
        targetPath = import_path.default.join(process.cwd(), "src/assets/images/founder_dhaval_1782221644891.jpg");
        customPath = import_path.default.join(customAssetsDir, "dhaval.jpg");
        import_fs.default.writeFileSync(targetPath, buffer);
        import_fs.default.writeFileSync(customPath, buffer);
        console.log(`Successfully updated founder Dhaval's photo at ${targetPath} and ${customPath}`);
      } else if (id === "logo") {
        targetPath = import_path.default.join(process.cwd(), "src/assets/images/accountveda_logo.svg");
        customPath = import_path.default.join(customAssetsDir, "logo.svg");
        if (mimeType.includes("svg")) {
          import_fs.default.writeFileSync(targetPath, buffer);
          import_fs.default.writeFileSync(customPath, buffer);
        } else {
          const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" width="100%" height="100%">
  <image href="${dataUrl}" x="0" y="0" width="500" height="500" />
</svg>`;
          import_fs.default.writeFileSync(targetPath, svgContent, "utf8");
          import_fs.default.writeFileSync(customPath, svgContent, "utf8");
        }
        console.log(`Successfully updated brand logo at ${targetPath} and ${customPath}`);
      } else {
        return res.status(400).json({ error: "Invalid asset ID" });
      }
      return res.json({ success: true, path: targetPath, customPath });
    } catch (error) {
      console.error("Error saving asset:", error);
      return res.status(500).json({ error: error.message || "Internal server error" });
    }
  });
  app.post("/api/reset-asset", (req, res) => {
    try {
      const { id } = req.body;
      if (!id) {
        return res.status(400).json({ error: "Missing id" });
      }
      const imagesDir2 = import_path.default.join(process.cwd(), "src/assets/images");
      let targetPath = "";
      let backupPath = "";
      let customPath = "";
      if (id === "chaitali") {
        targetPath = import_path.default.join(imagesDir2, "founder_chaitali_1782221629255.jpg");
        backupPath = import_path.default.join(imagesDir2, "default_chaitali.jpg");
        customPath = import_path.default.join(customAssetsDir, "chaitali.jpg");
      } else if (id === "dhaval") {
        targetPath = import_path.default.join(imagesDir2, "founder_dhaval_1782221644891.jpg");
        backupPath = import_path.default.join(imagesDir2, "default_dhaval.jpg");
        customPath = import_path.default.join(customAssetsDir, "dhaval.jpg");
      } else if (id === "logo") {
        targetPath = import_path.default.join(imagesDir2, "accountveda_logo.svg");
        backupPath = import_path.default.join(imagesDir2, "default_logo.svg");
        customPath = import_path.default.join(customAssetsDir, "logo.svg");
      } else {
        return res.status(400).json({ error: "Invalid asset ID" });
      }
      if (import_fs.default.existsSync(customPath)) {
        import_fs.default.unlinkSync(customPath);
      }
      if (import_fs.default.existsSync(backupPath)) {
        import_fs.default.copyFileSync(backupPath, targetPath);
        console.log(`Successfully restored default asset for ${id}`);
      }
      return res.json({ success: true });
    } catch (error) {
      console.error("Error resetting asset:", error);
      return res.status(500).json({ error: error.message || "Internal server error" });
    }
  });
  app.post("/api/save-testimonials", (req, res) => {
    try {
      const testimonials = req.body;
      if (!Array.isArray(testimonials)) {
        return res.status(400).json({ error: "Body must be a JSON array of testimonials" });
      }
      const targetPath = import_path.default.join(process.cwd(), "src/testimonials.json");
      import_fs.default.writeFileSync(targetPath, JSON.stringify(testimonials, null, 2), "utf8");
      console.log(`Successfully updated testimonials at ${targetPath}`);
      return res.json({ success: true, path: targetPath });
    } catch (error) {
      console.error("Error saving testimonials:", error);
      return res.status(500).json({ error: error.message || "Internal server error" });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
